public class practic1 {
    public static void printGreeting(String name) {
        System.out.println("привет " + name + "!");
    }

    public static void main(String[] args) {
        printGreeting("Дорогой");
    }
}